<?php die("Access Denied"); ?>#x#s:1390:"<?xml version="1.0" encoding="utf-8"?>
<extensions>
	<extension>
		<name>Advanced Module Manager</name>
		<id>advancedmodulemanager</id>
		<alias>advancedmodulemanager</alias>
		<extname>advancedmodules</extname>
		<version>7.1.1</version>
		<has_pro>1</has_pro>
		<pro>0</pro>
		<downloadurl>http://download.regularlabs.com/?ext=advancedmodulemanager</downloadurl>
		<downloadurl_pro></downloadurl_pro>
		<changelog><![CDATA[
<div style="font-family:monospace;font-size:1.2em;">18-Feb-2017 : v7.1.1<br /> # Fixes issue with match all usergroups setting not working<br /> # Fixes issue with php notice about an undefined property $advancedparams on some setups<br /> # Fixes issue with some select fields not being shows<br /> # Fixes issue with websites using certain encodings breaking<br /> # [PRO] Fixes issue with pdf and other non-html pages potentially breaking on some setups<br /><br />13-Feb-2017 : v7.1.0<br /> + Adds option to only pass Usergroup assignment if user has all usergroups from selection<br /> # Fixes issue with frontend editing not using the Advanced Module Manager layout<br /> # Fixes issue with raw/ajax calls potentially breaking<br /><br />07-Feb-2017 : v7.0.6<br /> # Fixes issue with updates for other 3rd party extensions not working<br /></div><div style="text-align: right;"><i>...click for more...</i></div>
		]]></changelog>
	</extension>
</extensions>";